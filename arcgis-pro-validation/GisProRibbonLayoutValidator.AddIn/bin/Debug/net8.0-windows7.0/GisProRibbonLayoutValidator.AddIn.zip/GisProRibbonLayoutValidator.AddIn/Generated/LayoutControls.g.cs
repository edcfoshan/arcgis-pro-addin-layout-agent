using System;



namespace GisProRibbonLayoutValidator.AddIn.Generated;



internal sealed class ExportCommandPlaceholder091fc1 : LayoutButtonBase
{
    public ExportCommandPlaceholder091fc1() : base("按钮", "ExportCommand", "currentView")
    {
    }
}

internal sealed class ExportCommandPlaceholder6e9e9c : LayoutButtonBase
{
    public ExportCommandPlaceholder6e9e9c() : base("按钮", "ExportCommand", "currentView")
    {
    }
}

internal sealed class ExportCommandPlaceholder01d3ce : LayoutButtonBase
{
    public ExportCommandPlaceholder01d3ce() : base("按钮", "ExportCommand", "currentView")
    {
    }
}

internal sealed class SelectToolPlaceholder7be73d : LayoutToolBase
{
    public SelectToolPlaceholder7be73d() : base("交互工具", "SelectTool", "map")
    {
    }
}

internal sealed class SelectToolPlaceholder831d97 : LayoutToolBase
{
    public SelectToolPlaceholder831d97() : base("交互工具", "SelectTool", "map")
    {
    }
}

internal sealed class SelectToolPlaceholder288707 : LayoutToolBase
{
    public SelectToolPlaceholder288707() : base("交互工具", "SelectTool", "map")
    {
    }
}

internal sealed class AddLayerSplitButtonPlaceholderrimary : LayoutButtonBase
{
    public AddLayerSplitButtonPlaceholderrimary() : base("分裂按钮", "AddLayerSplitButton", "menu")
    {
    }
}

internal sealed class AddLayerSplitButtonPlaceholderitem_1 : LayoutButtonBase
{
    public AddLayerSplitButtonPlaceholderitem_1() : base("分裂按钮主选项", "AddLayerSplitButton", "menu")
    {
    }
}

internal sealed class AddLayerSplitButtonPlaceholderitem_2 : LayoutButtonBase
{
    public AddLayerSplitButtonPlaceholderitem_2() : base("分裂按钮备选项", "AddLayerSplitButton", "menu")
    {
    }
}

internal sealed class AddLayerSplitButtonPlaceholderrimary : LayoutButtonBase
{
    public AddLayerSplitButtonPlaceholderrimary() : base("分裂按钮", "AddLayerSplitButton", "menu")
    {
    }
}

internal sealed class AddLayerSplitButtonPlaceholderitem_1 : LayoutButtonBase
{
    public AddLayerSplitButtonPlaceholderitem_1() : base("分裂按钮主选项", "AddLayerSplitButton", "menu")
    {
    }
}

internal sealed class AddLayerSplitButtonPlaceholderitem_2 : LayoutButtonBase
{
    public AddLayerSplitButtonPlaceholderitem_2() : base("分裂按钮备选项", "AddLayerSplitButton", "menu")
    {
    }
}

internal sealed class DrawPalettePlaceholdertool_1 : LayoutToolBase
{
    public DrawPalettePlaceholdertool_1() : base("工具板浏览", "DrawPalette", "map")
    {
    }
}

internal sealed class DrawPalettePlaceholdertool_2 : LayoutToolBase
{
    public DrawPalettePlaceholdertool_2() : base("工具板拾取", "DrawPalette", "map")
    {
    }
}

internal sealed class DrawPalettePlaceholdertool_3 : LayoutToolBase
{
    public DrawPalettePlaceholdertool_3() : base("工具板绘制", "DrawPalette", "map")
    {
    }
}

internal sealed class DrawPalettePlaceholdertool_1 : LayoutToolBase
{
    public DrawPalettePlaceholdertool_1() : base("工具板浏览", "DrawPalette", "map")
    {
    }
}

internal sealed class DrawPalettePlaceholdertool_2 : LayoutToolBase
{
    public DrawPalettePlaceholdertool_2() : base("工具板拾取", "DrawPalette", "map")
    {
    }
}

internal sealed class DrawPalettePlaceholdertool_3 : LayoutToolBase
{
    public DrawPalettePlaceholdertool_3() : base("工具板绘制", "DrawPalette", "map")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_1 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_1() : base("菜单第一项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_2 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_2() : base("菜单第二项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_3 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_3() : base("菜单第三项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_1 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_1() : base("菜单第一项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_2 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_2() : base("菜单第二项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_3 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_3() : base("菜单第三项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_1 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_1() : base("菜单第一项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_2 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_2() : base("菜单第二项", "OptionsMenu", "menu")
    {
    }
}

internal sealed class OptionsMenuPlaceholderitem_3 : LayoutButtonBase
{
    public OptionsMenuPlaceholderitem_3() : base("菜单第三项", "OptionsMenu", "menu")
    {
    }
}