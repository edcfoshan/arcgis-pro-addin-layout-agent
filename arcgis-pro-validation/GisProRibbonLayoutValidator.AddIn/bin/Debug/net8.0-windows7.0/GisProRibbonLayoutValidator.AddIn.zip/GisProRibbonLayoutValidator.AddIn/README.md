# GisProRibbonLayoutValidator.AddIn

This package was exported from the Ribbon designer.

Included files:
- Config.daml
- Generated/LayoutControls.g.cs
- Layout/current-layout.json
- GisProRibbonLayoutValidator.AddIn.csproj
- AddInModule.cs

Use this folder as the source for a local ArcGIS Pro Add-In build test.